# Copyright (c) 2014 Miguel Sarabia del Castillo
# Imperial College London
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
#

import rospy
import numpy as np

from .arta_serial_controller import ArtaSerialController
from .speed_profile import SpeedProfile

from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist
from arta_msgs.msg import Status
from std_srvs.srv import Empty as EmptySrv
from std_msgs.msg import Time

class Constants:
    rate = 20 # Hz, arduino update speed
    cmd_timeout = 0.2 # s, after this time stop wheelchair from moving
    default_frame = "base_link" # Default frame for messages out of this class
    default_speed = 1 # Starting speed for wheelchair
    shutdown_attempts = 5 # Try this many times to shutdown wheelchair
    joystick_deadzone =  0.1 # Below this combined axes value the joystick is inactive

class ROSArtaController:
    def __init__(self):
        self.__port = rospy.get_param("~port", "")
        self.__frame = rospy.get_param("~fixed_frame", Constants.default_frame)
        
        self.__speed_profile = SpeedProfile()
        self.__speed = rospy.get_param("~speed", Constants.default_speed)

        self.__lastest_joyX = 0.0
        self.__lastest_joyY = 0.0

        self.__onoff = True
        self.__last_update = rospy.Time.now()
            
        # Start ROS publishers/subscribers        
        self.__joy_pub = rospy.Publisher("joy", Joy, queue_size=1)       
        self.__status_pub = rospy.Publisher("arta_status", Status, queue_size=1)

        self.__cmd_sub = rospy.Subscriber("cmd_vel", Twist, self.__vel_callback)

        self.__on_srv = rospy.Service("shutdown", EmptySrv, self.__shutdown)
        self.__off_srv = rospy.Service("switch_on", EmptySrv, self.__switch_on)

        # Prepare rate
        self.__rate = rospy.Rate( Constants.rate )

    def __switch_on(self, req):
        self.__onoff = True
        return []

    def __shutdown(self, req):
        self.__onoff = False
        return []
   
    def __vel_callback(self, msg):
        results = self.__speed_profile.to_joystick(
            msg.linear.x,
            msg.angular.z,
            self.__speed)

        self.__lastest_joyX = results[0] 
        self.__lastest_joyY = results[1]
        self.__speed = results[2]
        self.__last_update = rospy.Time.now()  

    # If the joystick is inactive, do not publish a message
    def __is_active(self, joy):
        if np.linalg.norm(np.array(joy) - np.array([0,0])) <= Constants.joystick_deadzone:
            return False

        return True   

    def __publish_data(self, arta):
        # Get arta data
        joyX, joyY =  arta.get_joystick()
        speed = arta.get_speed()
        connected = arta.is_connected()
        switched_on = arta.is_switched_on()
        battery = arta.get_battery()

        # Joystick data
        joy_msg = Joy()
        joy_msg.header.stamp = rospy.Time.now()
        joy_msg.header.frame_id = self.__frame
        joy_msg.axes = [ joyX, joyY ]
        joy_msg.buttons = [ 1 ]

        if self.__is_active(joy_msg.axes):
            self.__joy_pub.publish(joy_msg)

        # Status data
        status_msg = Status()
        status_msg.connected = connected
        status_msg.switched_on = switched_on
        status_msg.speed = speed
        status_msg.battery = battery

        self.__status_pub.publish(status_msg)

    def __write_command(self, arta):
        joy_elapsed = (rospy.Time.now() - self.__last_update).to_sec()

        if joy_elapsed > Constants.cmd_timeout:
            self.__lastest_joyX = 0.0
            self.__lastest_joyY = 0.0

        arta.set_assistance( True )
        arta.set_switched_on( self.__onoff )
        arta.set_speed( self.__speed  )
        arta.set_joystick( (self.__lastest_joyX, self.__lastest_joyY) )

    def __get_feedback(self, msg):
        if msg.count("created"):
            rospy.loginfo(msg)
        elif msg.count("remaining attempts"):
            rospy.logwarn(msg)
        else:
            rospy.logerr(msg)
    
    def loop(self):
        if not self.__port:
            rospy.logerr("Required parameter ~port not specified")
            return

        rospy.loginfo("Starting ARTA serial controller")
        arta = ArtaSerialController(self.__port, self.__get_feedback)
        
        while not rospy.is_shutdown():
            if not arta.is_connected():
                rospy.logerr("Serial connection failed or timed out")
                break
            self.__publish_data(arta)
            self.__write_command(arta)
            self.__rate.sleep()

        rospy.loginfo("Stopping ARTA...")
        
        # Make sure arta is switched off when we stop
        attempts = Constants.shutdown_attempts
        while arta.is_switched_on() and arta.is_connected() and attempts:
            arta.set_switched_on( False )
            attempts -= 1
            self.__rate.sleep()
        
        arta.stop()
        rospy.loginfo("... Stopped")
