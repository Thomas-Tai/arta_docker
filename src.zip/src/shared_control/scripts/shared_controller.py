#!/usr/bin/env python

import rospy
import numpy as np

from collections import deque
from multiprocessing import Lock

from std_msgs.msg import Float32
from geometry_msgs.msg import Twist, TwistStamped

class Constants:
    rate = 10.0                     # ROS sampling rate, Hz
    deadzone = 0.125                # Below deadzone threshold, send out a zero twist message
    
class SharedController():

    def __init__(self):         
        self.__user_cmd = None
        self.__user_cmd_lock = Lock()

        # Safe commands that purely avoid obstacles (local planning)
        self.__obs_avoid_cmd = None
        self.__obs_avoid_cmd_lock = Lock()
        
        # Autonomy commands sent to our shared controller
        self.__auto_vel_cmd = None
        self.__auto_vel_cmd_lock = Lock()
        
        # Subscribers for the different command velocities
        user_cmd_sub_topic = rospy.get_param('~user_cmd_sub_topic', 'main_js_cmd_vel')
        rospy.Subscriber(user_cmd_sub_topic, Twist, self.__user_cmd_callback)

        obs_avoid_cmd_sub_topic = rospy.get_param('~obs_avoid_cmd_sub_topic', 'obs_avoid_vel')
        rospy.Subscriber(obs_avoid_cmd_sub_topic, Twist, self.__obs_avoid_cmd_callback)

        autonomy_cmd_sub_topic = rospy.get_param('~autonomy_cmd_sub_topic', 'auto_vel')
        rospy.Subscriber(autonomy_cmd_sub_topic, Twist, self.__auto_cmd_callback)
       
        # Publishers
        cmd_vel_pub_topic = rospy.get_param('~cmd_vel_pub_topic', 'cmd_vel')
        self.__cmd_vel_pub = rospy.Publisher(cmd_vel_pub_topic, Twist, queue_size=10)
        self.__twist_stamp_pub = rospy.Publisher(cmd_vel_pub_topic + '_stamped', TwistStamped, queue_size=10)
        
    def __user_cmd_callback(self, msg):
        self.__user_cmd_lock.acquire()
        self.__user_cmd = [msg.linear.x, msg.angular.z]
        self.__user_cmd_lock.release()
 
    def __obs_avoid_cmd_callback(self, msg): 
        self.__obs_avoid_cmd_lock.acquire()
        self.__obs_avoid_cmd = [msg.linear.x, msg.angular.z]
        self.__obs_avoid_cmd_lock.release()       
        
    def __auto_cmd_callback(self, msg):
        self.__auto_vel_cmd_lock.acquire()
        self.__auto_vel_cmd = [msg.linear.x, msg.angular.z]
        self.__auto_vel_cmd_lock.release()
        
    # If the robot is not moving and the current command is zero, publish a zero command
    def __is_active(self, cmd):
        if np.linalg.norm(np.array(cmd) - np.array([0,0])) <= Constants.deadzone:
            return False

        return True   
    
    def __assist_robot(self, cmd):
        assisted_vel = Twist()

        if self.__is_active(cmd):
            assisted_vel.linear.x, assisted_vel.angular.z = cmd[0], cmd[1]
        else:
            assisted_vel.linear.x, assisted_vel.angular.z = 0.0, 0.0

        assisted_vel_stamped = TwistStamped()
        assisted_vel_stamped.twist = assisted_vel
        assisted_vel_stamped.header.stamp = rospy.Time.now()

        self.__cmd_vel_pub.publish(assisted_vel)
        self.__twist_stamp_pub.publish(assisted_vel_stamped)
             
    def arbitrate_assistance(self):
        assist_cmd = None

        # If user commands are available
        if self.__user_cmd is not None:
            self.__user_cmd_lock.acquire()
            user_cmd = [self.__user_cmd[0], self.__user_cmd[1]]
            self.__user_cmd_lock.release()

            assist_cmd = user_cmd

        # If reactive collision avoidance is necessary
        if self.__obs_avoid_cmd is not None:
            self.__obs_avoid_cmd_lock.acquire()
            obs_avoid_cmd = [self.__obs_avoid_cmd[0], self.__obs_avoid_cmd[1]]
            self.__obs_avoid_cmd_lock.release()

            assist_cmd = obs_avoid_cmd

        # If autonomous assistance is provided, override obstacle avoidance
        if self.__auto_vel_cmd is not None:
            self.__auto_vel_cmd_lock.acquire()
            auto_vel_cmd = [self.__auto_vel_cmd[0], self.__auto_vel_cmd[1]]
            self.__auto_vel_cmd_lock.release()
            
            assist_cmd = auto_vel_cmd

        if assist_cmd is not None:
            # Send final data to robot's motors
            self.__assist_robot(assist_cmd)   

        # Reset commands
        self.__user_cmd = None
        self.__obs_avoid_cmd = None
        self.__auto_vel_cmd = None
        
# Main loop
def loop():
    # Initialize the node
    rospy.init_node('shared_controller', anonymous=True)

    # Create the Shared Control object
    sc = SharedController()

    rate = rospy.Rate(Constants.rate) 

    while not rospy.is_shutdown():
        sc.arbitrate_assistance()
        rate.sleep()

# Main function
if __name__ == '__main__':
    try:
        loop()
    except rospy.ROSInterruptException:
        pass
