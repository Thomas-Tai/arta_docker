To generate new models from blender files:

1) Adjust posture as needed from the model's skeleton (armature/pose)
2) Export as .obj to get the character in the correct posture (collada .dae not working for some reason)
3) Export as .dae to get the texture (.png) file (.obj doesn't export for some reason)
4) .dae file can be deleted
5) Adjust .mtl file generated together with .obj, make it point locally to the correct texture file
6) Open .obj in meshlab. Clip body parts if needed by selecting and deleting mesh faces.
7) Save body parts as separate .dae files to be used in urdf links

Tested with Blender version 2.79b.

A possible source for downloading free blender models is http://blendswap.com.

Might be a good idea, performance wise, to stick to meshes with low polygon count, specially if the model is to be used in simulators like Gazebo.
