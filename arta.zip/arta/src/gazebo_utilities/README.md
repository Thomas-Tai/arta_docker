# gazebo_utilities

Various utilities and tips for Gazebo simulation with ROS.

**Note** that [git-lfs](https://packagecloud.io/github/git-lfs) was used to minimise memory storage in this repository. Therefore it is preferred that you use `git lfs clone`, or alternatively `git lfs pull` to pull any updates to the repository. Two directories are currently being tracked: `docs` and `worlds/pictures`.

## Macros

A selection of Xacro (XML Macros) files that can be used for different robot model descriptions e.g. Gazebo plugins, IMUs, laser sensors, wheels etc. Use these to help simplify your `.urdf` files!

## Materials

Materials commonly used in Gazebo simulation, such as textures, are contained in the `materials` directory. 

All heightmap images are saved in this directory (*inverted* to obtain the desired heightmap effects). Note that loading a heightmap means you **must** first copy the `.png` file into your local Gazebo `media/materials/textures` directory.

## Meshes

Meshes for realistic visualisations of 3D models, objects, sensors etc. are contained in the `meshes` directory. Saved as `.dae` files and often found online rather than custom-made.

## Models

Any custom-designed models or those not available in Gazebo by default (like shapes with a static property) are contained in the `models` directory. These can also be inserted directly into a simulated world once you have imported them into your local `~/.gazebo/models` directory.

## Worlds

Configuration files for custom-defined Gazebo "worlds" are contained in the `worlds` directory. Many are based off environments around the PRL, such as the lift and hallway area. Small world variations are indicated by suffix numbers.

Simple worlds can easily be created directly in Gazebo, by using the Building Editor and/or adding elements to existing worlds. See these useful tutorials on the [Building Editor](http://gazebosim.org/tutorials?cat=build_world&tut=building_editor) and how to [build worlds](http://gazebosim.org/tutorials?tut=build_world).

## Tips

The `docs` directory contains a lab tutorial on using Gazebo with ROS.

You can launch a world (e.g. `example.world`) from ROS by creating a `.launch` file containing the following XML:
```xml
<arg name="world" default="example.world"/>

<include file="$(find gazebo_ros)/launch/empty_world.launch">
    <arg name="world_name" value="$(find gazebo_utilities)/worlds/$(arg world)"/>
</include>
```

**PRL Maps:** If you are using maps from [prl_localisation](https://github.com/ImperialCollegeLondon/prl_localisation) in simulation, then you will need to manually change the heightmap loaded `.png` files to correspond to the `.yaml` map description you wish to use. You can do this by first updating the `.world` file to point to your new heightmap, and then feeding the corresponding `.yaml` file into the localisation system.

**Heightmap Tip:** If you are modifying/upgrading any heightmaps stored locally in your Gazebo environment, then on launch your worlds may appear odd (e.g. black & yellow ground planes, zero sensor readings). In this case, navigate to your local `~/.gazebo/` directory and delete the `~/.gazebo/paging` directory. Heightmaps are cached in this directory and so all you have to do is delete the directory and re-launch your environment for things to work as normal!

**CPU-Laser:** If you do not have a GPU on your machine then the simulated laser scanners will not work. To fix this for a CPU-only machine, replace the Gazebo laser sensor types in `laser_scanners.xacro` from "gpu_ray" to "ray" and replace plugins "libgazebo_ros_gpu_laser.so" with "libgazebo_ros_laser.so".

**IRA laser-merger and time issues:** If you are using the laser merging strategy provided in `prl_localisation`, it tries to subscribe to topics for 20 seconds before initialising. However, when using simulated gazebo worlds, the simulated time used can make the node skip this initialisation period. This will be manifested by throwing an '[ERROR] [###, ###]: Not subscribed to any topic.' message without previously showing '[INFO]: Try to get laser topics' messages. To fix it, you can remove the time information from your world state, by deleting the \<sim_time\>, \<real_time\>, \<wall_time\> and \<iterations\> tags from your world file.

## Other Resources

**Mobile Robot Simulation:** If you are interested in mobile robot simulations then it is highly recommended that you follow this [tutorial](https://www.generationrobots.com/blog/en/2015/02/robotic-simulation-scenarios-with-gazebo-and-ros/) on how to simulate a mobile differential drive robot in Gazebo via a ROS interface.

**Heightmaps:** Useful link on how to create heightmaps for Gazebo is discussed [here](https://github.com/AS4SR/general_info/wiki/Creating-Heightmaps-for-Gazebo). 

**Gazebo-8+:** To migrate over to Gazebo-8 or higher versions instead of the fully integrated Gazebo-7 on ROS Kinetic, then you can adapt your installation by following this [link](https://medium.com/@abhiksingla10/setting-up-ros-kinetic-and-gazebo-8-or-9-70f2231af21a). Don't bother upgrading though unless absolutely necessary (e.g. for crowd simulation using [actor plugins](http://gazebosim.org/tutorials?tut=actor&cat=build_robot) like in `worlds/social.world`).
