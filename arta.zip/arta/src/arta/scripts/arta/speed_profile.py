# Copyright (c) 2014 Miguel Sarabia del Castillo
# Imperial College London
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
#

from collections import deque

class Constants:
    speeds = 5
    buffer_size = 20 # Size of buffer to low-pass filter changes in speed
    joystick_deadzone =  0.05 # Below this value the joystick is mapped to 0.0
    
    forward_speed_profile = [
        0.0,
        1.0, # max speed (in m/s) at speed 1
        2.0,
        3.0,
        4.0,
        5.0  # max speed (in m/s) at speed 5
    ]
    
    turning_speed_profile = [
        0.0,
        1.0, # max speed (in rad/s) at speed 1
        2.0,
        3.0,
        4.0,
        5.0  # max speed (in rad/s) at speed 5
    ]

class SpeedProfile:
    def __init__(self):
        init_list = [0] * Constants.buffer_size
        self.__speed_filter = deque( init_list, Constants.buffer_size )
    
    def __filter_speed(self, speed_level):
        #Add suggested speed to filter
        self.__speed_filter.append(speed_level)
        
        #Each of the last 20 suggested speeds gets a vote
        results = [0] * (Constants.speeds +1)  
        for entry in self.__speed_filter:
            results[entry] += 1
        
        #Now let's check if any speed_level has a simple majority
        for speed_level in range(Constants.speeds + 1):
            if results[speed_level] > (Constants.buffer_size / 2):
                return speed_level
        
        #Otherwise return 0, no change
        return 0
        
        
    def __suggested_speed(self, requested, profile):
        # NB 0 is no change in speed        
       
        #Try to find the closest matching speed_level
        for speed_level in range(Constants.speeds + 1):
            top_speed = profile[speed_level]
            if top_speed >= abs(requested):
                return speed_level
        
        #If no top_speed exceeded the requested speed return the maximum level
        return Constants.speeds
    
    def __choose_speed(self, forward_vel, turning_vel, current_speed_level):
        forward_speed_level = self.__suggested_speed(
            forward_vel,
            Constants.forward_speed_profile)
        
        turning_speed_level = self.__suggested_speed(
            turning_vel,
            Constants.turning_speed_profile)
        
        speed_level = max(forward_speed_level, turning_speed_level)
        
        filtered_speed_level = self.__filter_speed(speed_level)
        
        # If the filter managed to chose a speed return it, otherwise keep
        # current speed
        if filtered_speed_level:
            return filtered_speed_level
        else:
            return current_speed_level
    
    def __limit_joystick(self, joy):
        if joy > 1.0:
            return 1.0
        elif joy < -1.0:
            return -1.0
        elif abs(joy) < Constants.joystick_deadzone:
            return 0.0
        else:
            return joy
        
    def to_joystick(self, forward_vel, turning_vel, current_speed_level):
        new_speed_level = self.__choose_speed(
            forward_vel,
            turning_vel,
            current_speed_level )
        
        joyX = forward_vel / Constants.forward_speed_profile[new_speed_level]
        joyY = turning_vel / Constants.turning_speed_profile[new_speed_level]
        
        joyX = self.__limit_joystick( joyX )
        joyY = self.__limit_joystick( joyY )
        
        return ( joyX, joyY, new_speed_level)