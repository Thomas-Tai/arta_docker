# Copyright (c) 2014 Miguel Sarabia del Castillo
# Imperial College London
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
#

import os
import serial
import struct
import threading
import time

class Constants:
    fast_cycle = 0.05#s, normal arduino cycle
    slow_cycle = 1.0 #s, when disconected, try to reconnect every slow_cycle
    timeout = 0.20#s, consider signal lost after this time
    baud = 115200
    header = 255 # Header to detect beginning of packet
    version = 3 # Protocol version
    serial_connection_attempts = 3
    

def _encode_bool(value):
    return 2 if value else 1

def _decode_bool(value):
    return int(value) > 1

class Protocol:
    __struct = "BBBBfffi"
    size = struct.calcsize( __struct )

    def __init__(self):
        self.header = Constants.header
        self.speed = 0
        self.assistance = 0
        self.onoff = 0
        self.joyX = 0.0
        self.joyY = 0.0
        self.battery = 0.0
        self.version = Constants.version

    def encode(self):
        return struct.pack(
            self.__struct,
            self.header,
            self.speed,
            self.assistance,
            self.onoff,
            self.joyX,
            self.joyY,
            self.battery,
            self.version )

    def decode(self, data):
        unpacked = struct.unpack( self.__struct, data )

        self.speed = unpacked[1]
        self.assistance = unpacked[2]
        self.onoff = unpacked[3]
        self.joyX = unpacked[4]
        self.joyY = unpacked[5]
        self.battery = unpacked[6]
        self.version = unpacked[7]

        return (unpacked[0] == self.header)

    def  __bool__(self):
        return int(
            bool(self.speed) or
            bool(self.assistance) or
            bool(self.onoff) or
            bool(self.joyX) or
            bool(self.joyY) or
            bool(self.battery) )

    # For compatibility with python2
    __nonzero__ = __bool__


class ArtaSerialController:
    def __init__(self, port, callback = None):
        #Save callback to provide feedback
        self.__callback = callback
        
        #Port needs to be opened explicitly
        self.__serial =  serial.Serial(
            port = None,
            baudrate = Constants.baud,
            timeout = Constants.fast_cycle)
        
        self.__device = port
        self.__serial.port = self.__device

        #Protocol related variables
        self.__last_update = 0
        self.__info = Protocol()
        self.__cmd = Protocol()

        
        #Prepare thread
        self.__lock = threading.RLock()
        self.__thread = threading.Thread(target=self.__run)
        self.__running = False
        
        #Try to open serial port and start thread        
        if self.__open_serial_port():
            self.__running = True
            self.__thread.start()

    def __complete_cycle(self, start, duration):
            elapsed = time.clock() - start;
            remaining = duration - elapsed
            if remaining > 0:
                time.sleep(remaining)

    def __feedback(self, message):
        if self.__callback is not None:
            self.__callback(message)
            
    def stop(self):
        if self.__running:
            self.__running = False
            self.__thread.join()

    def __open_serial_port(self):
        attempts = Constants.serial_connection_attempts
        while attempts:
            start_time = time.clock()
            attempts -= 1
            try:
                self.__serial.open()
                self.__last_update = time.clock() #Do not timeout immediately
                self.__feedback("Connection to {} created".format(self.__device))
                return True
            except Exception as e:
                self.__feedback("Failed to create connection to {}".format(
                    self.__device))
                if attempts:                
                    self.__feedback(
                        "Device {} not found, remaining attempts {}".format(
                        self.__device, attempts ) )
                    self.__complete_cycle(start_time, Constants.slow_cycle)
                else:
                    self.__feedback( "An exception occured: {}".format(e) )
        return False
                
    def __run(self):
        try:
            while self.__running:
                #Variable to measure how long we stay in the loop
                start_time = time.clock()
                 
                new_info = Protocol()

                #Check if we have anything to read
                while self.__serial.inWaiting() >= Protocol.size:

                    raw_data = self.__serial.read( )

                    if ord(raw_data) != new_info.header:
                        continue

                    raw_data += self.__serial.read( Protocol.size-1 )
                    new_info.decode(raw_data)
                
                if new_info.version != Constants.version:
                    self.__feedback(
                        "Invalid version received: {}".format(new_info.version))

                #If we received new info save it and write command in reply
                with self.__lock:
                    if new_info:
                        # Save info we just read, so it can be checked by others
                        self.__info = new_info
                        self.__last_update = time.clock()

                    if self.__cmd:
                        # Prepare data to be sent
                        raw_data = self.__cmd.encode()

                        # Reset commmand (this will stop wheelchair 
                        # unless values are updated)
                        self.__cmd = Protocol()
                        
                        #Write command
                        self.__serial.write( raw_data )
                
                #Sleep till we complete cycle
                self.__complete_cycle(start_time, Constants.fast_cycle)

        except Exception as e:
            self.__feedback( "An exception occured: {}".format(e) )
        finally:
            self.__serial.close()
            
    def get_joystick(self):
        if self.is_connected(): 
            return (self.__info.joyX, self.__info.joyY)
        else:
            return (0.0, 0.0)

    def get_speed(self):
        return self.__info.speed

    def is_switched_on(self):
        return _decode_bool( self.__info.onoff )

    def get_assistance(self):
        return _decode_bool( self.__info.assistance )

    def get_battery(self):
        return self.__info.battery

    def is_connected(self):
        return ( self.__serial.isOpen() and 
                 self.__thread.isAlive() and 
                 (time.clock() - self.__last_update ) <= Constants.timeout)

    def set_joystick(self, values):
        if len(values) <2 or abs(values[0]) > 1.0 or abs(values[1])> 1.0:
            raise RuntimeError("Invalid values joystick values provided.")
            
        with self.__lock:
            self.__cmd.joyX = values[0]
            self.__cmd.joyY = values[1]

    def set_speed(self, value):
        if value < 1 or value > 5:
            raise RuntimeError("Invalid speed value provided.")

        with self.__lock:
            self.__cmd.speed = value

    def set_assistance(self, value):
        with self.__lock:
            self.__cmd.assistance = _encode_bool(value)

    def set_switched_on(self, value ):
        with self.__lock:
            self.__cmd.onoff = _encode_bool(value)

