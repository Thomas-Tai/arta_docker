# Navigation

Repository for assistive navigation of mobile robots used by the Personal Robotics Lab.

Navigational assistance switched over from the hybrid DWA-VFH method presented in the lab's [early mobility paper](https://spiral.imperial.ac.uk/handle/10044/1/12651) to a "gap-based" algorithm for reactive obstacle avoidance, known as the [admissible gap](https://www.sciencedirect.com/science/article/pii/S0921889017306905#!). 

Refer to the [archived](https://github.com/ImperialCollegeLondon/arta_archive) repository for more information on the original method, contained in the `obstacle_avoidance` package.

For all the other packages in this repository (described in the following sub-sections), please refer to the `arta_navigation` package of the [ARTA](https://github.com/ImperialCollegeLondon/arta) repository for example setups.

## Setup Instructions

To setup the git submodules in this repository for the first time, run the following command:
```shell
git submodule update --init --recursive
```

Then build your catkin workspace (e.g. using catkin_make or catkin build).

Once you have sourced your "devel" space, make sure to install all dependencies before launching the packages in this repository. You can use a command like this across your entire workspace:
```shell
rosdep install --from-paths src --ignore-src --rosdistro $ROS_DISTRO -y
```
Or alternatively for a specific package:
```
rosdep install package_name --ignore-src --rosdistro $ROS_DISTRO -y
```

This will install any missing ROS dependencies or notify you of missing packages from your "src" space (developed in the lab). If you cannot find some of these packages in rosdep (maybe due to your distro version) then just try launching the relevant packages. Contact one of the developers if you encounter any further issues.

## Reactive Assistance

The `reactive_assistance` package is now the sole driver of collision avoidance and local path planning in this repository. 

There is also the capability to send goals to this method for autonomous navigation by simply configuring the "goal_sub_topic" to the name of your published goal poses.

## Autonomous Navigation

For autonomous navigation on mobile robots (using the [move_base](http://wiki.ros.org/move_base) package on the ROS [navigation stack](http://wiki.ros.org/navigation)), you can find a template launch file in the `autonomous_navigation` package. An example of how to use this template is in `arta_navigation` of [ARTA](https://github.com/ImperialCollegeLondon/arta), where you can find the relevant parameter files in the `config/move_base/` directory.

## Shared Control

Finally, to achieve "shared control" in the pure sense of blending autonomy with human input, the `shared_control` package acts as a mediator between the three velocity commands available:
- Manual; no navigational assistance e.g. the direct user commands
- Obstacle avoidance; safely avoids collisions in a local planning sense e.g. the output of `reactive_assistance`
- Full autonomy; velocity commands generated to navigate towards a goal pose e.g. the output of `autonomous_navigation`

This package is very basic at the moment and works on a priority level, such that manual input is overridden by obstacle avoidance, which is further overridden by full autonomy.
