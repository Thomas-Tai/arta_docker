# Localisation

Repository for localising mobile robots used by the Personal Robotics Lab.

## Setup Instructions

To setup the git submodules in this repository for the first time, run the following command:
```shell
git submodule update --init --recursive
```

Then build your catkin workspace (e.g. using `catkin_make` or `catkin build`).

Once you have sourced your "devel" space, make sure to install all dependencies before launching the packages in this repository. You can use a command like this across your entire workspace:
```shell
rosdep install --from-paths src --ignore-src --rosdistro $ROS_DISTRO -y
```
Or alternatively for a specific package:
```
rosdep install package_name --ignore-src --rosdistro $ROS_DISTRO -y
```

This will install any missing ROS dependencies or notify you of missing packages from your "src" space (developed in the lab). If you cannot find some of these packages in rosdep (maybe due to your distro version) then just try launching the relevant packages. Contact one of the developers if you encounter any further issues.

## Package Breakdown

The `ira_laser_tools` package contains a node that takes as input multiple laser ranger readings and merges them into a single coherent message (also outputting a corresponding PointCloud). It is worth noting that this repository differs from the Kinetic distro version, and so pleasure ensure you make use of the package provided here for a working implementation (relates to [this](https://github.com/iralabdisco/ira_laser_tools/pull/16) pull request).

The `scan_image_converter` package contains a node that takes as input a laser scan message and converts it into a ROS image (polar to Cartesian space translation). 

The `localisation` package contains various ROS launchers for common SLAM and localisation packages, including RGB-D SLAM packages. These launchers are configured using parameters that have been tested on other mobile robots in the lab, so avoid changing these files on the *master* branch of this repository. There is also a `maps` directory containing maps for use with [AMCL](http://wiki.ros.org/amcl) across different mobile bases and different environments. **Please** place constructed maps that are robot-agnostic and quite generic in this same directory.
